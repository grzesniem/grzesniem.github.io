var lp = 0;
var x = 0;
var s = 0;
var p = 0;
var d = 0;

function DodajWpis() {
    var l = document.getElementById("dlugosc").value;
	
// Napisz instrukcję warunkową, która zwróci alert, gdy 'l' nie jest liczbą, lub jest puste. W innym przypadku wykona poniższe polecenia funkcji
	
    document.getElementById("container").innerHTML += lp + ". " + l + "<br>";
    var intL = Number(l);
	
// Napisz równanie, które zwiększa zmienną 'x' o zmienną 'intL'
// oraz równanie zwiększające 'lp' o 1

}

function Oblicz() {
    var y = x; s = 0; p = 0; d = 0;
    while (y > 0) {
// Dodaj instrukcje warunkowa
// 'y' > 90: 's' + 1, 'y' - 100
        
// 'y' > 40: 'p' + 1, 'y' - 50
        
// else: 'd' + 1, 'y' - 10

    }
	
	
// Dodaj alert wypisujący wartości 'x', 's', 'p', 'd'
    
}