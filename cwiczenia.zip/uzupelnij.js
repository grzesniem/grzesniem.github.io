var lp = 0;
var x = 0;

function DodajWpis() {
    var l = document.getElementById("dlugosc").value;

    // Napisz instrukcję warunkową, która zwróci alert, gdy 'l' nie jest liczbą, lub jest puste. W innym przypadku wykona poniższe polecenia funkcji

    document.getElementById("container").innerHTML += lp + ". " + l + "<br>";
    var intL = Number(l);


    // Napisz równanie, które zwiększa zmienną 'x' o zmienną 'intL'
    // oraz równanie zwiększające 'lp' o 1

}

function Oblicz() {
    var y = x;
    // Dodaj 3 zmienne, przechowujące ilość setek, piećdziesiątek i dziesiątek
    while (y > 0) {
        // Dodaj instrukcje warunkowa
        // 'y' > 90: setki + 1, 'y' - 100

        // 'y' > 40: pięćdziesiątki + 1, 'y' - 50

        // else: dziesiątki + 1, 'y' - 10

    }


    // Dodaj alert wypisujący wartość 'x', oraz liczbę setek, pięćdziesiątek i dziesiątek

}
